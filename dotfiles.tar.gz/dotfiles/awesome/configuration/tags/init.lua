local awful = require('awful')
local gears = require('gears')
local beautiful = require('beautiful')

local icons = require('theme.icons')

local tags = {
	{
		icon = icons.tag1,
		type = 'any',
		default_app = 'reaper',
		screen = 1
	},
	{
		icon = icons.tag2,
		type = 'any',
		default_app = 'ardour5',
		screen = 1
	},
	{
		icon = icons.tag3,
		type = 'any',
		default_app = 'Mixbus',
		screen = 1
	},
	{
	icon = icons.tag4,
		type = 'any',
	default_app = '',
		screen = 1
  },
	{
		icon = icons.tag5,
		type = 'any',
		default_app = '',
		screen = 1
	},
	{
		icon = icons.tag6,
		type = 'any',
		default_app = 'nemo',
		screen = 1
	},
	{
		icon = icons.tag7,
		type = 'any',
		default_app = 'atom',
		screen = 1
	},
	{
		icon = icons.tag8,
		type = 'any',
		default_app = 'kitty',
		screen = 1
	},
  {
	 icon = icons.web_browser,
	 type = 'chrome',
	 default_app = 'firefox',
	 screen = 1
 },
}


tag.connect_signal("request::default_layouts", function()
    awful.layout.append_default_layouts({
		awful.layout.suit.spiral.dwindle,
		awful.layout.suit.floating,
		awful.layout.suit.max
    })
end)


screen.connect_signal("request::desktop_decoration", function(s)
	for i, tag in pairs(tags) do
		awful.tag.add(
			i,
			{
				icon = tag.icon,
				icon_only = true,
				layout = awful.layout.suit.spiral.dwindle,
				gap_single_client = false,
				gap = beautiful.useless_gap,
				screen = s,
				default_app = tag.default_app,
				selected = i == 1
			}
		)
	end
end)


tag.connect_signal(
	'property::layout',
	function(t)
		local currentLayout = awful.tag.getproperty(t, 'layout')
		if (currentLayout == awful.layout.suit.max) then
			t.gap = 0
		else
			t.gap = beautiful.useless_gap
		end
	end
)
